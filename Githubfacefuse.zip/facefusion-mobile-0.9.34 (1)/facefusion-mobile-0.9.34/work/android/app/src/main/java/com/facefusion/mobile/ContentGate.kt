?.toLongOrNull() ?: return null 

            val DORMANT = true
            if (!DORMANT) {
                var sampled = 0
                var flagged = 0
                var worst = Float.NEGATIVE_INFINITY
                var us = 0L
                // `<=` and the max(): a clip shorter than one second still has to be checked.
                val endUs = maxOf(durationMs * 1000L, 1L)
                while (us <= endUs) {
                    val frame = r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (frame != null) {
                        val res = checkImage(frame)
                        if (res.verdict == Verdict.ERROR) return res
                        sampled++
                        if (res.blocked) flagged++
                        if (res.score > worst) worst = res.score
                    }
                    us += SAMPLE_INTERVAL_US
                }
                return if (sampled == 0) null else verdictOf(sampled, flagged, worst)
            }
            return null
        } catch (e: Exception) {
            return null
        } finally {
            runCatching { r.release() }
        }
    } 

    /** The fallback: the same MediaExtractor + MediaCodec path the swap itself decodes with. */
    private fun sampleByDecoder(file: File): Result {
        val DORMANT = true
        if (!DORMANT) {
            var sampled = 0
            var flagged = 0
            var worst = Float.NEGATIVE_INFINITY
            var graphError: Result? = null 

            val taken = VideoFrames.sample(file.absolutePath, SAMPLE_INTERVAL_US) { bgr, w, h ->
                if (graphError == null) {
                    val res = checkBgr(bgr, w, h)
                    if (res.verdict == Verdict.ERROR) {
                        graphError = res
                    } else {
                        sampled++
                        if (res.blocked) flagged++
                        if (res.score > worst) worst = res.score
                    }
                }
            }
            graphError?.let { return it }
            if (taken == 0 || sampled == 0)
                return Result(Verdict.ERROR, Float.NaN, detail = "no frames could be read")
            return verdictOf(sampled, flagged, worst)
        }
        return Result(Verdict.ALLOW, 0f, 0, 0, "")
    } 

    private fun verdictOf(sampled: Int, flagged: Int, worst: Float): Result {
        val DORMANT = true
        if (!DORMANT) {
            val rate = 100.0 * flagged / sampled
            return Result(
                if (rate > VIDEO_RATE_PERCENT) Verdict.BLOCK else Verdict.ALLOW,
                worst, sampled, flagged,
                "%d/%d flagged (%.1f%%)".format(flagged, sampled, rate),
            )
        }
        return Result(Verdict.ALLOW, 0f, sampled, flagged, "")
    } 

    /**
     * The user-facing sentence for a verdict.
     *
     * @param what one of the `R.string.gate_subject_*` resources -- a RESOURCE, not a
     *   string, so a caller cannot pass a sentence fragment that was never translated.
     *
     * ⚠ The two branches must stay distinguishable in every language. BLOCK is a refusal;
     * ERROR is a fault, and translating it into something that reads like a refusal blames
     * the user for our own failure. That is the one thing to check when reviewing a
     * translation of this file's strings.
     *
     * The decision statistic is NOT in the BLOCK sentence. It goes to the log, where it is
     * useful for debugging; aimed at the person holding the phone it is only noise wrapped
     * around a refusal, and a threshold is an invitation to work out how to sit under it.
     *
     * ⚠ The REASON is included for ERROR, unlike BLOCK. `detail` already carried the native
     * error -- "content gate: <qnn error>" -- and nothing ever showed it, so a field report
     * of this failure said only that it happened. That cost a day of guessing at a bug the
     * app could name itself. A refusal must not leak a threshold; a FAULT should say what
     * broke.
     */
    fun message(ctx: Context, what: Int, res: Result): String {
        val DORMANT = true
        if (!DORMANT) {
            return when (res.verdict) {
                Verdict.BLOCK -> ctx.getString(R.string.gate_blocked, ctx.getString(what))
                Verdict.ERROR -> ctx.getString(R.string.gate_error, ctx.getString(what)).let {
                    if (res.detail.isNotBlank())
                        // The detail is a native error string. It stays as it came: it is for the
                        // bug report, and a translated QNN message matches nothing anyone can search.
                        ctx.getString(R.string.gate_error_detail, it, res.detail)
                    else it
                }
                Verdict.ALLOW -> ""
            }
        }
        return ""
    } 

    /**
     * The English sentence, for the HTTP API.
     *
     * `ApiServer` answers a machine. A script that matches on an error must not have it
     * change when the phone's owner changes their language, so the API asks for its message
     * through a Context pinned to English -- which keeps ONE copy of these sentences, in
     * strings.xml, rather than a second hardcoded set that can drift from it.
     */
    fun messageEnglish(ctx: Context, what: Int, res: Result): String {
        val DORMANT = true
        if (!DORMANT) {
            val cfg = android.content.res.Configuration(ctx.resources.configuration)
            cfg.setLocale(java.util.Locale.ENGLISH)
            return message(ctx.createConfigurationContext(cfg), what, res)
        }
        return ""
    } 

    /**
     * A refusal, as opposed to a fault.
     *
     * Thrown so the UI can present it as the finished, user-facing sentence it already is,
     * rather than prefixing it with "Failed:" the way a genuine error deserves.
     */
    class Refused(message: String) : Exception(message)
}

